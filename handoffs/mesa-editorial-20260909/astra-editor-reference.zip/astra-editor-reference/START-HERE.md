# Astra comparison reference — open after your first result is saved

Read `Astra-editor-report.md` for the outcome in the common reporting format. `editorial-decisions.json` accounts for every original resource ID and records suggested improvements. `autoMesa.html` is the editable 268-resource review application. Its “What changed” link opens optional bold comparisons. The ZIP is the full research draft, not a human-curated package.

This reference is an informed editorial result, not a truth set. Use the separate main handover for mission/context and instructions. Original source records are included here for the decision ledger's references; the original research ZIP is in the main packet. No patron records or contact attempts were added to prepare this reference.
