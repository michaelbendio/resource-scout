# Editorial outcome — Mesa — Astra — September 9, 2026

## 1. Outcome in one minute

The broad 460-resource research draft became an editable **268-resource collection across 19 categories**, with overlapping records consolidated and navigation adjusted. It is ready for human phone curation, not a phone-verified release. Michael welcomed the reduction. Actual curator feedback on these selections is still pending.

Open [autoMesa.html](autoMesa.html), its [short comparison summary](autoMesa-editorial-summary.html), the [draft package](autoMesa-editorial-draft.zip), or the [full decisions](editorial-decisions.json).

| Measure | Result |
| --- | --- |
| Original unique records | 460 |
| Reviewed / unreviewed | 460 / 0 |
| Retained source records | 268 |
| Source records folded into retained entries | 41, into 32 retained destinations |
| Reserved / excluded | 123 / 28 |
| New output identities from additions or splits | 0 |
| Final unique resources / categories | 268 / 19 |
| Estimated provider calls | Unknown; program/contact relationships need checking |
| New provider checks / human approvals created | 0 / 0 |

268 + 41 + 123 + 28 = 460. There were **309 selected source records before combination**; 41 were folded into the retained 268. Housing has 54 memberships, Employment 45 and Clothing 19. Memberships overlap; 268 ÷ 19 is not the visible per-category count. Call savings and curator time savings were not measured.

## 2. Assignment and method

- Editor identity: Astra, as used in the conversation; exact runtime model/version was not recorded in this artifact.
- Baseline: September 9 `autoMesaV2-research-draft.zip`, SHA-256 `e62e012837d0fc909775e26cc21c831b30c3035c357f2ee02b1ec4171073eea0`; full 460-record research draft for Mesa, not a final human-curated package.
- Method: informed editorial preparation. The editor had prior research context and authored the initial suitability review. This was not an independent blind trial.
- Initial review: all 460 descriptions, eligibility and entry instructions; Important Information cross-checks throughout, open-question titles for retained records, and selected complete question explanations. Consolidation additionally examined relevant original program details and questions. This was not a fresh source-by-source audit of every claim.
- Research: saved evidence only; no outside model assignments or new provider checks in this editorial stage.
- Timing/cost: not separately instrumented; no measured total or monetary claim. Broad-run costs must not be presented as this edit's costs.
- Authority: select, consolidate, rewrite and adjust taxonomy in a separate autoMesa draft, preserving original files and human status. No active playbook or production office change.

## 3. Most consequential decisions

1. **Inaccessible clothing route left out.** Dignity Threads required an approved nonprofit partner, normally after four to six months of participation, without a known usable approved partner. That is a weak ordinary clothing referral for TSO patrons. An undiscovered accessible intake remains possible; no new provider call was made.
2. **Useful consolidated entry.** Paz de Cristo · Meals, Showers, Clothing, Mail and ID Help (`08a26b747ffe8b1ea284e491a62d39e7`) received the overlapping saved program details, including clothing limits, food timing, document help and job-related transportation. Critical service-specific instructions remained explicit.
3. **A combination recommendation was corrected.** AzEIP · Infant and Toddler Developmental Help (`90ef7bed032bcd935b0f82e65f664917`) stays separate from Arizona DES · Child Care Aid and Early Development Help (`b48b75beadedb73dd0606ffb3dcc568d`) and Arizona DES · Disability Services, Early Intervention and Caregiver Help (`eb94f24384f8e51a2b237d7d8c507948`). Common agency ownership did not justify combining distinct help.
4. **Scope and tags changed together.** Arizona Veterans’ Services · Benefits, Emergency Aid and Nursing Care (`fb402105bec44e0623b4ccf8d7064802`) now describes benefits and hardship aid, with nursing scope removed. Salvation Army Mesa · Utility, Food and Emergency Help (`fcdf7044337d12d9e7bdd3a7a732fd08`) no longer advertises an unsupported open rent-help route; food, cooling/basic needs and utility help retain their appropriate navigation.
5. **Distinctive alternatives preserved.** Known school-clothing routes and Mesa Native American pathways were considered on actual usefulness; neither specialist eligibility nor a referral requirement alone triggered removal.

The optional HTML comparisons show revised wording in **bold**, with removed text struck through. Full original records are preserved in the package's editorial metadata and the original source JSON.

## 4. Coverage, navigation and human handoff

Caregiving was removed under Michael's scope direction. Thirteen unused types were removed from surviving categories; misleading assignments were corrected and six meaningful types added for bank accounts, computers/internet and transportation. All 19 existing groups still have members and were retained. No numerical category cap or group-membership quota was applied.

The remaining collection still has large categories and uncertain provider facts. Curators should examine every retained entry, call the appropriate providers using their established script, settle open questions and confirm the text and navigation. They may restore a reserved option or reject an AI-retained one. The decision ledger gives the evidence and reason for reconsideration. Michael need not answer provider questions to let other work proceed.

## 5. Validation and limitations

| Check | Result and evidence |
| --- | --- |
| Original ID accounting, counts, definitions, selected package | Passed; `artifact-verification.json` and `editorial-manifest.json` |
| Original records, candidates, question evidence, verification dates | Preserved in the authored draft; no new human approvals |
| Actual navigation and combined type/group filters | Passed in isolated Chrome; `browser-verification.json` |
| Actual edit, Done, save/reload and resolution history | Passed using synthetic edits that never entered delivery |
| Curated-selection ZIP export and provenance | Passed; selected entry only, with editorial metadata/questions |
| Compatible office merge, older package re-import and save | Passed using isolated `mesa-import-demo.html`; answer/history survived. This does not establish behavior of every existing office file. |
| Storage for changes to all 268 entries | Passed; `storage-capacity-verification.json` |
| Responsive display | Desktop and iPad-size browser screenshots inspected; not a physical-iPad test |
| Patron print layout for the new 268 edition | Not separately rerun; uses the existing Scout template. Individual handout length still deserves curator review. |
| Actual attachment payload preservation | Original Mesa baseline had no packaged asset files; this edition does not demonstrate real-PDF transfer |

The source research ZIP was unchanged. The prior autoMesa was backed up; production `mesa.html`, `new.html` and the prior autoMesaV2 research file were unchanged. A draft omission is not an office deletion instruction. Selection based on saved evidence can be wrong; neither Michael's approval of the reduction nor synthetic QA is provider verification.

## 6. Suggestions from this work

The four proposals in `editorial-decisions.json` describe their evidence, scope, alternative explanations, counterexamples and bounded tests:

- **A1 — Practical entry routes:** ask whether the person and missionary can actually start the named help; evaluate both inaccessible inclusions and useful referrals wrongly excluded.
- **A2 — Service-aware consolidation:** distinguish true duplicates from different help under one organization; measure loss of critical facts as well as entry reduction.
- **A3 — Whole-resource consistency:** reconcile descriptions and navigation after program scope changes, preserving the concise five-section writing approach.
- **A4 — Attributable curator feedback:** compare this saved decision record with subsequent real curation without interpreting every edit or omission as a verified error.

These are **proposed**, not activated learning. Current strengths worth preserving include concrete curator questions, short useful titles, source-to-destination evidence and a reversible editable draft. A modest first experiment should target one change; it should not repeat the entire expensive multi-AI research run by default.

## 7. Comparison with another editor

Not yet performed. This is the reference result, not ground truth. Have the next editor freeze its independent decisions before opening this pack if comparison is the goal, then examine consequential disagreements and later curator outcomes. Preserve cases where the other editor improves on this selection.

## 8. Next step

Discuss an implementation plan for the missing learning loop, then design the integrated frontier-editor workflow. Start with traceable proposed edits and recommendations; evaluate evidence before expanding particular editorial authorities. No new automated editor or learning increment was implemented by this handover.
