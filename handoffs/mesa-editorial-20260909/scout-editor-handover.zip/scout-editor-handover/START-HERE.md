# Start here: Resource Scout editorial trial

This packet lets another frontier-level AI prepare Scout research for the people who will use it: service missionaries helping people with real needs, and human curators who check details and call providers.

Michael: start with **`michael-editor-handover-checklist.md`** (also supplied as HTML). It explains what to send for a new handover, including how to avoid sending an older HTML snapshot or a partial curated-only export.

## Give the editor this instruction

> Read `frontier-editor-handover.md`. Use the 460-record Mesa research in `inputs/original-resources.json` (also supplied as `inputs/original-research.zip`) for an editorial trial. Apply practical judgment to retain, combine, reserve or exclude resources; improve writing and navigation within the brief's scope. Account for every original ID using `frontier-editor-decision-format.md` and describe the result using `frontier-editor-report-template.md`. Preserve evidence and human history. Begin with saved research, identify any consequential gaps, and do not invent verification or mark records human-curated. Prepare a separate editable draft if your tools support the actual application/package format; otherwise provide complete proposed changes and clearly identify the remaining construction work. Save your first decisions before looking at any previous editor's selections. Give concise progress updates and promptly disclose a blocker. Do not run additional paid AI services or change production files as part of this review.

Michael may change the assignment or supply a different office/baseline. Record that scope explicitly. No per-category count target is imposed.

## Files to use

1. **`frontier-editor-handover.md`** — context, missionary/curator workflow, Scout's capabilities and limits, and editorial recommendations. An HTML reading copy is also supplied.
2. **`frontier-editor-report-template.md`** — common short outcome report with optional evidence.
3. **`frontier-editor-decision-format.md`** — full, comparable decisions by resource ID. This is an interchange proposal, not an existing Scout API.
4. **`inputs/`** — the original research before Astra's selection, with stable IDs, saved information, sources and questions. The JSON contains the resource array; the ZIP also contains office taxonomy/package metadata. `original-autoMesa.html` is a newly rendered full review application using that exact 460-resource package snapshot. It does not include anyone's later browser-local edits. The ZIP is the authoritative baseline; the HTML demonstrates presentation and editing. This particular source package has no packaged attachment files.
5. **`examples/`** — the approved writing example. Its provider facts are historical source material, not newly verified advice.
6. **`technical-reference/`** — optional implementation/design background. These are dated documents; their older progress/next-step paragraphs are not current execution status. They may link to repository files not included here. The main handover states the reviewed capabilities and limits.

The full source response archive and Scout database are not bundled. Ask for specific missing evidence if needed; do not claim to have read it. Browsing is not required for a saved-research editorial trial. If you make additional web checks, distinguish them and their dates from the baseline evidence, and compare their added research cost separately.

## Comparing editors fairly

The separate `astra-editor-reference.zip` contains Astra's decisions and final 268-resource draft. For an independent editorial comparison, withhold it until the first result is saved. Use a fresh conversation when necessary: asking a model to forget already-seen answers does not make the test blind. The main brief contains shared policy and illustrative editorial lessons, so this is a comparison under common guidance, not an untouched research-discovery experiment.

For an informed revision, opening the reference at the outset is fine; label that method. Counts are not a score or target. Evaluate consequential disagreements, coverage, practical access, preserved details, curator effort and measured time/cost. Human curator judgments are still pending for this AI-prepared collection.

No research or editor run was launched to prepare this packet. The new learning machinery and integrated editor workflow remain subjects for Michael's next design discussion.
