# Mesa Clothing pilot — editorial outcome

**21 Clothing resources ready for human curation:** all 19 existing entries retained, plus two additions. Four existing entries have clearer patron text; one new question needs a provider answer.


[Open the Clothing pilot](autoMesaClothingPilot.html) · [Download the full pilot package](autoMesaClothingPilot.zip) · 


The package contains all **21 pilot resources**. It is a partial Mesa collection, not a replacement for the full office package. The original 268-resource draft is unchanged; merging this pilot with it would yield 270 unique resources.




## What changed




- **The Worker:** housing follow-up changes from nine months to **one year**. The provider now describes a **shared one-bedroom apartment, a 2–3 month wait, job-tenure/pay-stub requirements, and saving 80% of net pay toward a $5,000 goal**. Job-search and clothing access remain separate from housing eligibility.

- **La Mesa Ministries:** the title and description now show **clothing and meals**. The instructions explicitly place clothing, hygiene items and daily bus passes at the weekly gatherings.

- **Mesa Community College:** the description now specifies **student clothing at Southern/Dobson** and distinguishes the public food events.

- **Streets of Joy:** callers are asked for **sizes and pickup arrangements**; an unnecessary instruction to declare program residency was removed. Its existing nonresident-access question remains.



## Two additions



- **City Hope Gilbert — Clothing and Food.** Free walk-in help with government ID, one visit to each center per month, and a capacity cutoff. The existing City Hope Mesa site provides food only.

- **Jose’s Closet — Clothing, Baby Supplies and Food.** A separate Mesa option for foster, kinship and adoptive families, with first-visit documentation, monthly clothing/diapers and weekly food. It stays separate from Helen’s Hope Chest because the provider and intake rules differ.


## One new question for the curator


**How often can a household get clothing from New Hope?** Grok found a Findhelp listing reviewed August 21, 2026 saying once every 90 days. New Hope’s own page gives clothing hours but no repeat-visit interval. Ask **480-807-1668** whether that limit still applies and whether urgent needs have exceptions. The question is saved in the resource editor with its source and context.


All earlier question IDs, notes and any answers are preserved. Some older questions overlap; this run does not resolve or silently delete them.




## What the independent check contributed


Astra froze its 19 rechecks and four discovery passes before Grok received the original records. Grok returned all 19 rechecks and one discovery result, independently finding Jose’s Closet. Astra confirmed the Worker housing correction. It rejected an inferred new appointment requirement at Dress for Success: the provider’s FAQ still explicitly permits walk-ins and requires no referral. Existing fee and voucher questions were preserved without adding duplicates.


City Hope Gilbert was found and verified by Astra; Grok’s search did not identify it. Grok read part of the full identity catalog; Astra checked additions against all 268 saved records. This bounded search does not establish exhaustive coverage. No provider calls or human approvals were made.




## Navigation and handoff


The four Clothing types remain available. The pilot retains only groups and types used by its resources. Existing cross-category memberships are preserved. New groups were not inferred from general public availability. The ZIP contains all pilot entries; the app’s normal curated-selection export remains available for curators.




## What this teaches us


The blind check found a useful correction, but its appointment inference needed editorial judgment. A focused next experiment should test whether a researcher checks explicit eligibility statements on sibling program/FAQ pages before inferring a restriction from an appointment button or a missing detail. These are learning observations, not activated lessons.


**Grand plan:** research → frontier editing → human curation → later maintenance and evaluated learning. Next, review this small pilot and use a later curator package or resolved question as feedback. This run saved 21 editorial observations; it did not run a lesson-promotion experiment or establish that Grok is faster or more accurate than Claude.


## Validation

Passed; see browser-verification.json.

## Timing and provenance

Successful Grok pass: 6.8 minutes. CLI accounting: $0.2579, not a confirmed subscription charge. See manifest.json and the full ledgers for identities, source hashes and coverage.
